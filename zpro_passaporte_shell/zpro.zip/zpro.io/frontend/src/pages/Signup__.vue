
<template>
    <div>
        <!-- Select para escolher plano -->
        <label for="planSelect">Escolha um Plano:</label>
        <select v-model="selectedPlanId" @change="handlePlanChange">
            <option v-for="plan in planos" :key="plan.id" :value="plan.id">
                {{ plan.value }} - Conexões: {{ plan.connections }} - Usuários: {{ plan.users }}
            </option>
        </select>

        <!-- Formulário de envio -->
        <form @submit.prevent="submitForm">
            <input type="text" v-model="formValue" placeholder="Valor (R$)" />
            <input type="number" v-model="formConnections" placeholder="Conexões" />
            <input type="number" v-model="formUsers" placeholder="Usuários" />
            <button type="submit">Enviar</button>
        </form>
    </div>
</template>

<script>
export default {
    data() {
        return {
            planos: [], // Lista de planos
            selectedPlanId: null, // ID do plano selecionado
            formValue: '', // Valor do input no formulário
            formConnections: '', // Conexões do input no formulário
            formUsers: '' // Usuários do input no formulário
        };
    },
    methods: {
        listarPlanos() {
            // Função para buscar planos e armazenar na lista
            this.planos = [
                { id: 3, value: "100.00", connections: 1, users: 1 },
                { id: 4, value: "150.00", connections: 3, users: 3 }
            ];
        },
        handlePlanChange() {
            // Método para definir valores do formulário baseado no plano selecionado
            const selectedPlan = this.planos.find(plan => plan.id === this.selectedPlanId);
            if (selectedPlan) {
                this.formValue = selectedPlan.value;
                this.formConnections = selectedPlan.connections;
                this.formUsers = selectedPlan.users;
            }
        },
        submitForm() {
            const formData = {
                value: this.formValue,
                maxUsers: this.formUsers,
                maxConnections: this.formConnections
            };
            console.log("Dados enviados:", formData);
            // Realizar ação de submissão conforme necessário
        }
    },
    created() {
        this.listarPlanos(); // Carregar planos ao criar componente
    }
};
</script>
